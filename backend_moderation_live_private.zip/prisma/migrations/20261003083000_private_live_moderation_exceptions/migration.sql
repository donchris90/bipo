ALTER TABLE "ModerationRule"
ADD COLUMN "enforceInPrivate" BOOLEAN NOT NULL DEFAULT true;

-- Public-live safety remains strict, while ordinary profanity and external-contact
-- filters are relaxed in private 1:1/party rooms. Threats, harassment, scams and
-- other severe rules remain enforced in private contexts.
UPDATE "ModerationRule"
SET "enforceInPrivate" = false
WHERE "category" IN ('PROFANITY', 'EXTERNAL_CONTACT');
