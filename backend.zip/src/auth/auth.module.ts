import { ACCESS_TOKEN_DEFAULT, tokenLifetime } from '../common/token-lifetime';
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './strategies/jwt.strategy';
import { EmailModule } from '../notifications/email/email.module';
import { EconomyModule } from '../economy/economy.module';
import { ReferralConfigModule } from '../referral-config/referral-config.module';

@Module({
  imports: [
    PassportModule,
    ConfigModule,
    EmailModule,
    EconomyModule,
    ReferralConfigModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.get<string>('JWT_ACCESS_SECRET'),
        signOptions: { expiresIn: tokenLifetime(config.get<string>('JWT_ACCESS_EXPIRES_IN'), ACCESS_TOKEN_DEFAULT) },
      }),
    }),
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
