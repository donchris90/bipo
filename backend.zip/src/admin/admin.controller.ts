import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { RoleName } from '@prisma/client';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

interface AuthedRequest extends Request {
  user: { userId: string; roles: RoleName[]; countryCode: string };
}

const ANY_ADMIN = [RoleName.SUPER_ADMIN, RoleName.FINANCE_ADMIN, RoleName.TRUST_SAFETY_ADMIN, RoleName.GAME_OPERATOR];
const TRUST_SAFETY = [RoleName.SUPER_ADMIN, RoleName.TRUST_SAFETY_ADMIN];
const FINANCE = [RoleName.SUPER_ADMIN, RoleName.FINANCE_ADMIN];
const GAMES = [RoleName.SUPER_ADMIN, RoleName.GAME_OPERATOR];

// Read-only data for the admin dashboard. Each route is limited to the roles
// that are allowed to act on that data; the dashboard's write actions use the
// existing guarded endpoints (users/:id/suspend, withdrawals/:id/approve, ...).
@Controller('api/v1/admin')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AdminController {
  constructor(private readonly admin: AdminService) {}

  @Get('overview')
  @Roles(...ANY_ADMIN)
  overview(@Req() req: AuthedRequest) {
    return this.admin.overview(req.user.roles);
  }

  @Get('users')
  @Roles(...TRUST_SAFETY, RoleName.FINANCE_ADMIN)
  users(@Query() q: Record<string, unknown>) {
    return this.admin.users(q);
  }

  @Get('creator-applications')
  @Roles(...TRUST_SAFETY)
  creatorApplications(@Query() q: Record<string, unknown>) {
    return this.admin.creatorApplications(q);
  }

  @Get('withdrawals')
  @Roles(...FINANCE)
  withdrawals(@Query() q: Record<string, unknown>) {
    return this.admin.withdrawals(q);
  }

  @Get('purchases')
  @Roles(...FINANCE)
  purchases(@Query() q: Record<string, unknown>) {
    return this.admin.purchases(q);
  }

  @Get('agencies')
  @Roles(...TRUST_SAFETY)
  agencies(@Query() q: Record<string, unknown>) {
    return this.admin.agencies(q);
  }

  @Get('live-sessions')
  @Roles(...ANY_ADMIN)
  liveSessions(@Query() q: Record<string, unknown>) {
    return this.admin.liveSessions(q);
  }

  @Get('audit-log')
  @Roles(...TRUST_SAFETY)
  auditLog(@Query() q: Record<string, unknown>) {
    return this.admin.auditLog(q);
  }

  @Get('moderation-actions')
  @Roles(...TRUST_SAFETY)
  moderationActions(@Query() q: Record<string, unknown>) {
    return this.admin.moderationActions(q);
  }

  @Get('games')
  @Roles(...GAMES)
  games() {
    return this.admin.games();
  }
}
