import { notConfigured } from '../../common/provider-mode';

// Same shape as RtcProvider / PaymentProvider: the service depends only on
// this interface, and the module picks the implementation from env. Swap or
// add a provider (Cloudinary, Bunny, Mux, ...) here without touching
// VideosService.
export interface StorageProvider {
  // A short-lived URL the *client* uploads the file to directly, so video
  // bytes never pass through this server.
  createUpload(params: {
    key: string;
    contentType: string;
  }): Promise<{ uploadUrl: string; method: 'PUT'; headers: Record<string, string>; expiresInSeconds: number }>;

  // Null when nothing has been uploaded at that key (yet).
  headObject(key: string): Promise<{ sizeBytes: number } | null>;

  // The URL a viewer plays from.
  publicUrl(key: string): string;

  deleteObject(key: string): Promise<void>;
}

export const STORAGE_PROVIDER = 'STORAGE_PROVIDER';

// Used in production when no bucket is configured: uploads and publishing fail
// with a 503 instead of accepting videos that are then thrown away.
export class UnavailableStorageProvider implements StorageProvider {
  async createUpload(): Promise<never> {
    return notConfigured('Video storage', 'set S3_BUCKET and its credentials');
  }
  async headObject(): Promise<never> {
    return notConfigured('Video storage', 'set S3_BUCKET and its credentials');
  }
  publicUrl(): string {
    return '';
  }
  async deleteObject(): Promise<void> {
    /* nothing stored */
  }
}

// Dev-only. Issues an upload URL nothing listens on and pretends every key
// exists, so the whole publish flow can be exercised without a bucket. It
// does NOT store anything — videos published against it have a URL that
// cannot be played.
export class MockStorageProvider implements StorageProvider {
  async createUpload({ key }: { key: string; contentType: string }) {
    return { uploadUrl: `mock://upload/${key}`, method: 'PUT' as const, headers: {}, expiresInSeconds: 900 };
  }

  async headObject() {
    return { sizeBytes: 1 };
  }

  publicUrl(key: string) {
    return `mock://media/${key}`;
  }

  async deleteObject() {
    /* nothing stored */
  }
}
