import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DeleteObjectCommand, HeadObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import type { StorageProvider } from './storage-provider.interface';

const UPLOAD_URL_TTL_SECONDS = 900;

// Any S3-compatible store: AWS S3, Cloudflare R2, DigitalOcean Spaces,
// MinIO, Backblaze B2. Set S3_ENDPOINT for everything except AWS itself.
//
// Config: S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY,
//   S3_REGION (default "auto" — what R2 expects; use e.g. "us-east-1" for AWS),
//   S3_ENDPOINT (optional), S3_PUBLIC_BASE_URL (required — the CDN / public
//   bucket URL videos are played from, e.g. https://media.example.com).
//
// Not exercised against a real bucket in this sandbox (no network to one):
// test an actual upload + playback with your credentials before relying on
// it. The bucket also needs a CORS rule allowing PUT from the app.
@Injectable()
export class S3StorageProvider implements StorageProvider {
  private readonly client: S3Client;
  private readonly bucket: string;
  private readonly publicBase: string;

  constructor(config: ConfigService) {
    const bucket = config.get<string>('S3_BUCKET');
    const accessKeyId = config.get<string>('S3_ACCESS_KEY_ID');
    const secretAccessKey = config.get<string>('S3_SECRET_ACCESS_KEY');
    const publicBase = config.get<string>('S3_PUBLIC_BASE_URL');
    if (!bucket || !accessKeyId || !secretAccessKey || !publicBase) {
      throw new Error('S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY and S3_PUBLIC_BASE_URL must all be set');
    }
    this.bucket = bucket;
    this.publicBase = publicBase.replace(/\/+$/, '');
    this.client = new S3Client({
      region: config.get<string>('S3_REGION') ?? 'auto',
      endpoint: config.get<string>('S3_ENDPOINT') || undefined,
      credentials: { accessKeyId, secretAccessKey },
      // R2 / MinIO / Spaces are happiest with path-style when an endpoint is custom.
      forcePathStyle: !!config.get<string>('S3_ENDPOINT'),
    });
  }

  async createUpload({ key, contentType }: { key: string; contentType: string }) {
    const uploadUrl = await getSignedUrl(
      this.client,
      new PutObjectCommand({ Bucket: this.bucket, Key: key, ContentType: contentType }),
      { expiresIn: UPLOAD_URL_TTL_SECONDS },
    );
    // The client must send this exact Content-Type or the signature fails.
    return {
      uploadUrl,
      method: 'PUT' as const,
      headers: { 'Content-Type': contentType },
      expiresInSeconds: UPLOAD_URL_TTL_SECONDS,
    };
  }

  async headObject(key: string) {
    try {
      const head = await this.client.send(new HeadObjectCommand({ Bucket: this.bucket, Key: key }));
      return { sizeBytes: Number(head.ContentLength ?? 0) };
    } catch (e: any) {
      if (e?.name === 'NotFound' || e?.$metadata?.httpStatusCode === 404) return null;
      throw e;
    }
  }

  publicUrl(key: string) {
    return `${this.publicBase}/${key}`;
  }

  async deleteObject(key: string) {
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}
