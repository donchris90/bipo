import { Module } from '@nestjs/common';
import { CreatorApplicationService } from './creator-application.service';
import { CreatorAnalyticsService } from './creator-analytics.service';
import { WithdrawalService, PAYOUT_PROVIDER } from './withdrawal.service';
import {
  CreatorsController,
  CreatorApplicationsAdminController,
  WithdrawalsController,
} from './creators.controller';
import { PayoutWebhookController } from './payout-webhook.controller';
import { MockPayoutProvider, UnavailablePayoutProvider } from './providers/payout-provider.interface';
import { isProduction } from '../common/provider-mode';
import { EconomyModule } from '../economy/economy.module';
import { RiskModule } from '../risk/risk.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [EconomyModule, RiskModule, NotificationsModule],
  providers: [
    CreatorApplicationService,
    CreatorAnalyticsService,
    WithdrawalService,
    {
      provide: PAYOUT_PROVIDER,
      // The mock invents a payout reference and never moves money, so it is
      // for development only. In production withdrawals are refused (503)
      // until a real payout provider is integrated.
      useClass: isProduction() ? UnavailablePayoutProvider : MockPayoutProvider,
    },
  ],
  controllers: [
    CreatorsController,
    CreatorApplicationsAdminController,
    WithdrawalsController,
    PayoutWebhookController,
  ],
  exports: [CreatorApplicationService, WithdrawalService],
})
export class CreatorsModule {}
