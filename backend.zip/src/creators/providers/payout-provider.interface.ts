import { notConfigured } from '../../common/provider-mode';

export interface PayoutProvider {
  // False when no real payout provider is wired in (see UnavailablePayoutProvider).
  // Checked BEFORE any money is reserved, so a withdrawal that cannot be paid out
  // is refused up front rather than reserved, failed and released.
  readonly isConfigured?: boolean;

  initiatePayout(params: {
    userId: string;
    amountMinor: number;
    currencyCode: string;
    idempotencyKey: string;
  }): Promise<{ providerRef: string }>;

  // Real implementations report status asynchronously via webhook, not a
  // synchronous return — this mock simplifies to immediate success for
  // local development only.
  handleWebhook(payload: unknown): Promise<{ providerRef: string; status: 'paid' | 'failed'; reason?: string }>;
}

// The provider used in production. No real payout integration exists in this
// codebase yet (the mock below just invents a reference), so withdrawals are
// refused with a 503 rather than pretending money was sent.
export class UnavailablePayoutProvider implements PayoutProvider {
  readonly isConfigured = false;
  async initiatePayout(): Promise<never> {
    return notConfigured('Payouts', 'a payout provider has not been integrated');
  }
  async handleWebhook(): Promise<never> {
    return notConfigured('Payouts', 'a payout provider has not been integrated');
  }
}

export class MockPayoutProvider implements PayoutProvider {
  async initiatePayout(params: { idempotencyKey: string }) {
    return { providerRef: `mockpayout_${params.idempotencyKey}` };
  }

  async handleWebhook(payload: any) {
    return { providerRef: payload?.providerRef ?? 'unknown', status: 'paid' as const };
  }
}
