import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuditModule } from './audit/audit.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { RegionalConfigModule } from './config/regional-config.module';
import { FeatureFlagsModule } from './feature-flags/feature-flags.module';
import { SocialModule } from './social/social.module';
import { NotificationsModule } from './notifications/notifications.module';
import { MessagesModule } from './messages/messages.module';
import { CallsModule } from './calls/calls.module';
import { SearchModule } from './search/search.module';
import { FeedModule } from './feed/feed.module';
import { LiveModule } from './live/live.module';
import { RoomsModule } from './rooms/rooms.module';
import { RealtimeModule } from './realtime/realtime.module';
import { EconomyModule } from './economy/economy.module';
import { CreatorsModule } from './creators/creators.module';
import { AgenciesModule } from './agencies/agencies.module';
import { PkModule } from './pk/pk.module';
import { GamesModule } from './games/games.module';
import { QueueModule } from './queue/queue.module';
import { JobsModule } from './jobs/jobs.module';
import { ReconciliationModule } from './reconciliation/reconciliation.module';
import { MissionsModule } from './missions/missions.module';
import { VideosModule } from './videos/videos.module';
import { UploadsModule } from './uploads/uploads.module';
import { AdminModule } from './admin/admin.module';
import { PayoutsModule } from './payouts/payouts.module';
import { KycModule } from './kyc/kyc.module';
import { AnnouncementsModule } from './announcements/announcements.module';
import { ProfilesModule } from './profiles/profiles.module';
import { WebhookRouterModule } from './common/webhook-router.service';
import { HostLevelsModule } from './host-levels/host-levels.module';
import { RrydaLevelsModule } from './rryda-levels/rryda-levels.module';
import { SupporterLevelsModule } from './supporters/supporter-levels.module';
import { FanClubsModule } from './fan-clubs/fan-clubs.module';
import { BadgesModule } from './badges/badges.module';
import { TeamsModule } from './teams/teams.module';
import { SeasonsModule } from './seasons/seasons.module';
import { OnboardingModule } from './onboarding/onboarding.module';
import { MatchingModule } from './matching/matching.module';
import { ModerationModule } from './moderation/moderation.module';
import { HealthModule } from './health/health.module';
import { C2CModule } from './c2c/c2c.module';
import { RrydaExperienceModule } from './experience/experience.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]), // baseline rate limit; tighten per-route later (auth, gifts, entries)
    PrismaModule,
    AuditModule,
    QueueModule,
    AuthModule,
    UsersModule,
    RegionalConfigModule,
    FeatureFlagsModule,
    SocialModule,
    NotificationsModule,
    MessagesModule,
    CallsModule,
    SearchModule,
    FeedModule,
    LiveModule,
    RoomsModule,
    RealtimeModule,
    EconomyModule,
    CreatorsModule,
    AgenciesModule,
    PkModule,
    GamesModule,
    JobsModule,
    ReconciliationModule,
    MissionsModule,
    VideosModule,
    UploadsModule,
    AdminModule,
    PayoutsModule,
    KycModule,
    AnnouncementsModule,
    ProfilesModule,
    WebhookRouterModule,
    HostLevelsModule,
    RrydaLevelsModule,
    SupporterLevelsModule,
    FanClubsModule,
    BadgesModule,
    TeamsModule,
    SeasonsModule,
    OnboardingModule,
    MatchingModule,
    ModerationModule,
    HealthModule,
    C2CModule,
    RrydaExperienceModule,
  ],
})
export class AppModule {}
