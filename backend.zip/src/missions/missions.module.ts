import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MissionsService } from './missions.service';
import { MissionsController, AdminMissionsController } from './missions.controller';
import { EconomyModule } from '../economy/economy.module';
import { RrydaLevelsModule } from '../rryda-levels/rryda-levels.module';
import { BadgesModule } from '../badges/badges.module';
import { TeamsModule } from '../teams/teams.module';
import { SeasonsModule } from '../seasons/seasons.module';

@Module({
  imports: [ConfigModule, EconomyModule, RrydaLevelsModule, BadgesModule, TeamsModule, SeasonsModule],
  providers: [MissionsService],
  controllers: [MissionsController, AdminMissionsController],
})
export class MissionsModule {}
