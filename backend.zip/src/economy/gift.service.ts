import { DAY_MS, DEFAULT_DAY_OFFSET_MINUTES, dayPeriod } from '../common/day-period';
import { BadRequestException, ConflictException, Injectable, NotFoundException, Optional } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { WalletService } from './wallet.service';
import { NotificationsService } from '../notifications/notifications.service';
import { RevenueSplitService, ResolvedSplit } from './revenue-split.service';
import { EXTENDED_TX_OPTIONS } from '../prisma/prisma-transaction-options';
import { WalletType, LedgerEntryType, ChatContext } from '@prisma/client';
import { pkPointsForCoins, pkSideForRecipient } from './pk-score';
import { HostLevelsService } from '../host-levels/host-levels.service';
import { RrydaLevelsService } from '../rryda-levels/rryda-levels.service';
import { TeamsService } from '../teams/teams.service';
import { SupporterLevelsService } from '../supporters/supporter-levels.service';
import { RoomCommunityService } from '../rooms/room-community.service';
import { SeasonsService } from '../seasons/seasons.service';
import { createMoment } from '../experience/experience.moments';
import { applyRoomPkScore } from './room-pk-score';
import { drawLuckyReward, luckyGameType } from './lucky-gift';

// Pure and exported for the same reason as games/settlement.service.ts's
// isWinningSelection: this is money math, so it gets a direct unit test
// rather than only indirect coverage through send().
//
// Agency commission (spec §34) comes out of the creator's share, not the
// platform's — the platform's cut is fixed by RevenueSplitConfig regardless
// of whether the recipient has an agency. This is a deliberate design
// choice (an alternative would be the agency taking a cut of the platform
// share, or of the whole gift) made explicit here since the spec doesn't
// dictate it.
export function computeGiftSplit(
  coinAmount: number,
  split: ResolvedSplit,
  agencyCommissionBps = 0,
): { creatorShare: number; platformShare: number; agencyShare: number } {
  if (!Number.isInteger(coinAmount) || coinAmount <= 0) throw new Error('Gift coin amount must be a positive integer');
  if (!Number.isInteger(agencyCommissionBps) || agencyCommissionBps < 0 || agencyCommissionBps > 10_000) {
    throw new Error('Agency commission must be between 0 and 10000 bps');
  }
  if (
    !Number.isInteger(split.creatorShareBps) ||
    !Number.isInteger(split.platformShareBps) ||
    split.creatorShareBps < 0 ||
    split.platformShareBps < 0 ||
    split.creatorShareBps > 10_000 ||
    split.platformShareBps > 10_000 ||
    split.creatorShareBps + split.platformShareBps !== 10_000
  ) {
    throw new Error('Creator and platform shares must total 100%');
  }
  const totalCreatorPool = Math.floor((coinAmount * split.creatorShareBps) / 10000);
  const platformShare = coinAmount - totalCreatorPool; // remainder to platform — avoids rounding leaks from splitting 3 ways with floor()
  const agencyShare = agencyCommissionBps > 0 ? Math.floor((totalCreatorPool * agencyCommissionBps) / 10000) : 0;
  const creatorShare = totalCreatorPool - agencyShare;
  return { creatorShare, platformShare, agencyShare };
}

export interface SendGiftParams {
  senderId: string;
  recipientId: string;
  giftId: string;
  context?: ChatContext;
  contextId?: string;
    // Ignored as a source of truth: the server works out whether the
  // recipient is in an ACTIVE PK itself (see resolvePkBattleId). Kept so
  // older app versions that still send it keep working.
  pkBattleId?: string;
  idempotencyKey: string;
}

export interface BackpackGift {
  giftId: string;
  code: string | null;
  name: string;
  icon: string | null;
  count: number;
  coinValue: number;
  senders: { userId: string; displayName: string | null; count: number }[];
}
export interface BackpackDay {
  date: string; // YYYY-MM-DD in Nigeria time
  isToday: boolean;
  totalCount: number;
  totalCoins: number;
  gifts: BackpackGift[];
}

const dayKey = (d: Date, offsetMinutes: number) => new Date(d.getTime() + offsetMinutes * 60_000).toISOString().slice(0, 10);

// Pure, so the grouping has direct tests. Every day in the span is returned (a day
// with nothing received is an empty day), newest first.
export function groupBackpack(
  rows: { giftId: string; senderId: string; coinAmount: number; createdAt: Date }[],
  giftById: Map<string, { id: string; code: string; name: string; icon: string | null }>,
  nameById: Map<string, string | null>,
  todayStart: Date,
  offsetMinutes: number,
  span: number,
): BackpackDay[] {
  const days = new Map<string, BackpackDay>();
  const todayKey = dayKey(todayStart, offsetMinutes);
  for (let i = 0; i < span; i++) {
    const key = dayKey(new Date(todayStart.getTime() - i * DAY_MS), offsetMinutes);
    days.set(key, { date: key, isToday: key === todayKey, totalCount: 0, totalCoins: 0, gifts: [] });
  }
  const perDayGift = new Map<string, BackpackGift>();
  const perDayGiftSender = new Map<string, Map<string, number>>();
  for (const r of rows) {
    const key = dayKey(r.createdAt, offsetMinutes);
    const day = days.get(key);
    if (!day) continue;
    const gk = `${key}|${r.giftId}`;
    let g = perDayGift.get(gk);
    if (!g) {
      const info = giftById.get(r.giftId);
      g = { giftId: r.giftId, code: info?.code ?? null, name: info?.name ?? 'Gift', icon: info?.icon ?? null, count: 0, coinValue: 0, senders: [] };
      perDayGift.set(gk, g);
      day.gifts.push(g);
      perDayGiftSender.set(gk, new Map());
    }
    g.count += 1;
    g.coinValue += r.coinAmount;
    day.totalCount += 1;
    day.totalCoins += r.coinAmount;
    const sm = perDayGiftSender.get(gk)!;
    sm.set(r.senderId, (sm.get(r.senderId) ?? 0) + 1);
  }
  for (const [gk, g] of perDayGift) {
    g.senders = [...perDayGiftSender.get(gk)!.entries()]
      .map(([userId, count]) => ({ userId, displayName: nameById.get(userId) ?? null, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }
  for (const day of days.values()) day.gifts.sort((a, b) => b.coinValue - a.coinValue);
  return [...days.values()];
}

@Injectable()
export class GiftService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly wallet: WalletService,
    private readonly revenueSplit: RevenueSplitService,
    // Optional so the money logic stays constructible (and unit-testable)
    // without the notification stack; in the running app it is always
    // injected. Never awaited for its result and never able to fail a gift.
    @Optional() private readonly notifications?: NotificationsService,
    @Optional() private readonly hostLevels?: HostLevelsService,
    // Same optional pattern as hostLevels above, and the same rule: never awaited for its
    // result, never able to fail a gift. This one grows the SENDER's Rryda Identity (the doc's
    // "Support" dimension) — separate from hostLevels above, which grows the RECIPIENT's.
    @Optional() private readonly rrydaLevels?: RrydaLevelsService,
    @Optional() private readonly supporterLevels?: SupporterLevelsService,
    // Same optional pattern as the others above, never able to fail a gift. Only fires for
    // ROOM-context gifts (see the hook below) — awardGiftXp itself resolves the session's
    // contextId to the persistent Room.
    @Optional() private readonly roomCommunity?: RoomCommunityService,
    // Same optional pattern again — grows the SENDER's team (if they're on one), same full
    // coinAmount as rrydaLevels above, not the /50 conversion (Rryda Teams contribution is meant
    // to feel 1:1, see TeamsService.contributeXp).
    @Optional() private readonly teams?: TeamsService,
    // Same optional pattern again — full coinAmount, same as teams above, into whichever
    // season(s) are currently running (contributePoints itself is a no-op if none are).
    @Optional() private readonly seasons?: SeasonsService,
  ) {}

  // Backing for a gift-picker UI — before this, the only way a client
  // could know what to pass as giftId to POST /gifts/send was to already
  // know it, since nothing returned the catalog. Only active gifts, since
  // an inactive one would just 404 if someone tried to send it anyway.
  async catalog() {
    return this.prisma.gift.findMany({
      where: { active: true },
      orderBy: { coinPrice: 'asc' },
      select: { id: true, code: true, name: true, coinPrice: true, category: true, icon: true, luckyEnabled: true, luckyType: true, luckyRewards: true },
    });
  }

  async send(params: SendGiftParams) {
    if (params.senderId === params.recipientId) {
      throw new BadRequestException('Cannot send a gift to yourself');
    }

    const existing = await this.prisma.giftTransaction.findUnique({
      where: { idempotencyKey: params.idempotencyKey },
    });
    if (existing) {
      // A retry must come from the same sender. Never hand one user another user's transaction
      // (and its lucky result) because a key happened to collide.
      if (existing.senderId !== params.senderId) throw new ConflictException('Idempotency key already used');
      return existing; // idempotent on retry
    }

    const gift = await this.prisma.gift.findUnique({ where: { id: params.giftId } });
    if (!gift || !gift.active) throw new NotFoundException('Gift not available');

    const sender = await this.prisma.user.findUnique({ where: { id: params.senderId } });
    if (!sender) throw new NotFoundException('Sender not found');

    const split = await this.revenueSplit.resolve(sender.countryCode);
    const coinAmount = gift.coinPrice;
    const lucky = gift.luckyEnabled && gift.luckyRewards ? drawLuckyReward(gift.luckyRewards) : null;
    const luckyCoins = lucky?.coins ?? 0;
    const luckyType = lucky ? luckyGameType(gift.luckyType) : null;

    // Which PK (if any) this gift counts towards, decided here from the
    // recipient — never trusted from the client.
    const pkBattleId = await this.resolvePkBattleId(params);

    // Agency commission lookup kept inline here (Prisma query, not an
    // AgenciesService import) for the same reason as the PK-score hook
    // below — avoids a circular dependency between Economy and Agencies.
    const membership = await this.prisma.agencyMembership.findFirst({
      where: { creatorId: params.recipientId, status: 'ACTIVE' },
    });
    const agency = membership ? await this.prisma.agency.findUnique({ where: { id: membership.agencyId } }) : null;

    const { creatorShare, platformShare, agencyShare } = computeGiftSplit(
      coinAmount,
      split,
      membership?.commissionBps ?? 0,
    );

    // Same fix as EntryService.place(): every wallet movement plus the
    // GiftTransaction record that justifies them must commit together.
    // Before this, a failure in giftTransaction.create() after the debit/
    // credits had already gone through would move real money with no
    // transaction record — the exact bug class found live in the game
    // entry flow, same shape here.
    const transaction = await this.prisma.$transaction(async (tx) => {
      // 1. Debit sender's coin wallet (checks sufficient balance).
      await this.wallet.debit(
        {
          userId: params.senderId,
          walletType: WalletType.COIN,
          amount: BigInt(coinAmount),
          ledgerType: LedgerEntryType.GIFT_SENT,
          reference: params.idempotencyKey,
          idempotencyKey: `gift_sent:${params.idempotencyKey}`,
        },
        tx,
      );

      // 2. Credit recipient's creator-earnings wallet with their share.
      if (creatorShare > 0) {
        await this.wallet.credit(
          {
            userId: params.recipientId,
            walletType: WalletType.CREATOR_EARNINGS,
            amount: BigInt(creatorShare),
            ledgerType: LedgerEntryType.GIFT_RECEIVED,
            reference: params.idempotencyKey,
            idempotencyKey: `gift_received:${params.idempotencyKey}`,
          },
          tx,
        );
      }

      // 3. Record the platform's share (not a user wallet — see LedgerEntry.walletId comment).
      if (platformShare > 0) {
        await this.wallet.recordPlatformEntry(
          {
            ledgerType: LedgerEntryType.GIFT_RECEIVED,
            amount: BigInt(platformShare),
            reference: params.idempotencyKey,
            idempotencyKey: `gift_platform:${params.idempotencyKey}`,
          },
          tx,
        );
      }

      // 3b. Credit the agency owner's commission, if the recipient has an
      // active agency membership. Comes out of the creator's pool (see
      // computeGiftSplit comment), so this doesn't change platformShare.
      if (agency && agencyShare > 0) {
        await this.wallet.credit(
          {
            userId: agency.ownerId,
            walletType: WalletType.AGENCY_EARNINGS,
            amount: BigInt(agencyShare),
            ledgerType: LedgerEntryType.AGENCY_COMMISSION,
            reference: params.idempotencyKey,
            idempotencyKey: `gift_agency:${params.idempotencyKey}`,
          },
          tx,
        );
      }

      // Lucky Gifts return bonus coins to the SENDER. The reward is selected
      // server-side and credited in the same transaction as the gift debit,
      // so a retry can never create a second bonus.
      if (luckyCoins > 0) {
        await this.wallet.credit(
          {
            userId: params.senderId,
            walletType: WalletType.COIN,
            amount: BigInt(luckyCoins),
            ledgerType: LedgerEntryType.BONUS,
            reference: params.idempotencyKey,
            idempotencyKey: `gift_lucky_bonus:${params.idempotencyKey}`,
          },
          tx,
        );
        // The bonus coins are newly issued to the sender, so the platform books the same
        // amount as an expense (negative, walletId null). Without this the ledger shows
        // coins appearing from nowhere and platform revenue is overstated.
        await this.wallet.recordPlatformEntry(
          {
            ledgerType: LedgerEntryType.BONUS,
            amount: -BigInt(luckyCoins),
            reference: params.idempotencyKey,
            idempotencyKey: `gift_lucky_platform:${params.idempotencyKey}`,
          },
          tx,
        );
      }

      // Party seats display the gift value received during the current seat
      // session. The RoomSeat row is deleted when the guest leaves, so the
      // next visit starts from zero while the room-wide gift total remains
      // cumulative in GiftTransaction.
      if (params.context === 'ROOM' && params.contextId) {
        await tx.roomSeat.updateMany({
          where: { roomId: params.contextId, userId: params.recipientId },
          data: { giftCoins: { increment: coinAmount } },
        });
      }

      return tx.giftTransaction.create({
        data: {
          senderId: params.senderId,
          recipientId: params.recipientId,
          giftId: gift.id,
          coinAmount,
          context: params.context,
          contextId: params.contextId,
          pkBattleId,
          creatorShareCoins: creatorShare,
          platformShareCoins: platformShare,
          agencyShareCoins: agencyShare,
          creatorShareBps: split.creatorShareBps,
          platformShareBps: split.platformShareBps,
          agencyCommissionBps: membership?.commissionBps ?? 0,
          agencyId: agency?.id ?? null,
          agencyOwnerId: agency?.ownerId ?? null,
          luckyRewardCoins: luckyCoins,
          luckyRewardLabel: lucky?.label ?? null,
          luckyType,
          idempotencyKey: params.idempotencyKey,
        },
      });
    }, EXTENDED_TX_OPTIONS);

    // Feed committed room gifts into the active multi-guest Room PK. This is deliberately
    // after the paid transaction commits: a scoring failure must never roll back a real gift.
    if (params.context === 'ROOM' && params.contextId) {
      try {
        await applyRoomPkScore(this.prisma, params.contextId, params.recipientId, coinAmount);
      } catch {
        // Room PK scoring is supplementary game state; the gift transaction is already committed.
      }
    }

    // Large gifts become Rryda Moments so the social layer has memorable events to surface.
    // The threshold is intentionally conservative to avoid filling the feed with every small gift.
    if (coinAmount >= 1000) {
      void createMoment(this.prisma, {
        userId: params.recipientId,
        type: 'GIFT_MILESTONE',
        title: `A ${coinAmount.toLocaleString()}-coin gift arrived`,
        description: 'A standout gift moment from your community.',
        payload: { senderId: params.senderId, coinAmount, context: params.context ?? null, contextId: params.contextId ?? null },
      }).catch(() => undefined);
    }

    if (this.hostLevels) {
      try { await this.hostLevels.awardRule(params.recipientId, 'GIFT_100_COINS', Math.floor(coinAmount / 100)); } catch { /* progression must never fail a paid gift */ }
    }
    if (this.rrydaLevels) {
      void this.rrydaLevels.addXp(params.senderId, Math.floor(coinAmount / 50));
    }
    // Grows the (sender, recipient) supporter relationship specifically — separate from
    // rrydaLevels above, which grows the sender's platform-wide identity. Full coinAmount, no
    // conversion (see supporter-levels.service.ts): this is meant to track cumulative spend on
    // this one creator directly.
    if (this.supporterLevels) {
      void this.supporterLevels.addXp(params.senderId, params.recipientId, coinAmount);
    }
    // A gift sent inside a Party Room also grows the sender's standing in that room's
    // community (and, more slowly, the room's own level) — see RoomCommunityService.
    // params.contextId here is the live PartyRoom session id; awardGiftXp resolves it to the
    // persistent Room itself.
    if (this.roomCommunity && params.context === 'ROOM' && params.contextId) {
      void this.roomCommunity.awardGiftXp(params.contextId, params.senderId, coinAmount);
    }
    if (this.teams) {
      void this.teams.contributeXp(params.senderId, coinAmount);
    }
    if (this.seasons) {
      void this.seasons.contributePoints(params.senderId, coinAmount);
    }

    // 4. If sent during an active PK battle, feed the score. Kept outside
    // the financial transaction above deliberately — a PK score is a
    // display/game-state concern, not money, and a failure here shouldn't
    // roll back a gift that has already legitimately happened. Kept inline
    // here (rather than a PKService import) to avoid a circular dependency
    // between Economy and PK — PK depends on gift data, not the reverse.
    if (pkBattleId) {
      try {
        await this.applyPkScore(pkBattleId, params.recipientId, coinAmount);
      } catch {
        /* score is game state, never a reason to fail a paid gift */
      }
    }

    // Deliberately NO notification here. A busy stream can receive hundreds of
    // gifts; each one used to add to the recipient's inbox and buzz their phone,
    // burying everything else. A gift is shown where it happens — the on-screen
    // gift moment in the live / room — and counted in the creator's earnings.
    // (Existing gift notifications in old inboxes still display; new ones are
    // not created.)

    // Broadcasting the gift event to the live/room WebSocket channel happens
    // in the controller/gateway layer, which has access to the Socket.IO
    // server instance — this service stays transport-agnostic.
    return transaction;
  }

  // A gift sent in a live counts for a PK when its recipient is one of the
  // two hosts of an ACTIVE battle. Gifts outside a live (rooms, video tips)
  // never count.
  private async resolvePkBattleId(params: SendGiftParams): Promise<string | null> {
    if (params.context && params.context !== 'LIVE') return null;
    const direct = await this.prisma.pKBattle.findFirst({
      where: { status: 'ACTIVE', OR: [{ challengerId: params.recipientId }, { opponentId: params.recipientId }] },
      select: { id: true },
      orderBy: { startedAt: 'desc' },
    });
    if (direct) return direct.id;

    // Team/Agency PK: a gift to any of the snapshotted participants (captured once at challenge
    // time — see PkService.teamChallenge / agencyChallenge) counts, but only while the recipient
    // is themself hosting the live it was sent in. Deliberately NOT a live membership lookup:
    // joining a team or agency after the challenge was sent must never add scoring surface to it.
    if (!params.contextId) return null;
    const liveSession = await this.prisma.liveSession.findFirst({ where: { id: params.contextId, hostId: params.recipientId, status: 'LIVE' }, select: { id: true } });
    if (!liveSession) return null;
    const poolBattle = await this.prisma.pKBattle.findFirst({
      where: {
        status: 'ACTIVE',
        mode: { in: ['TEAM', 'AGENCY'] },
        OR: [{ challengerParticipantIds: { has: params.recipientId } }, { opponentParticipantIds: { has: params.recipientId } }],
      },
      select: { id: true },
      orderBy: { startedAt: 'desc' },
    });
    return poolBattle?.id ?? null;
  }

  private async applyPkScore(pkBattleId: string, recipientId: string, coinAmount: number) {
    const battle = await this.prisma.pKBattle.findUnique({ where: { id: pkBattleId } });
    if (!battle || battle.status !== 'ACTIVE') return; // gift still counts financially even if PK isn't live
    if (battle.endsAt && battle.endsAt.getTime() <= Date.now()) return; // buzzer has sounded

    let side = pkSideForRecipient(battle, recipientId);
    if (!side && (battle.mode === 'TEAM' || battle.mode === 'AGENCY')) {
      // Snapshot-based, same as resolvePkBattleId above — never a live membership lookup.
      if (battle.challengerParticipantIds?.includes(recipientId)) side = 'CHALLENGER';
      else if (battle.opponentParticipantIds?.includes(recipientId)) side = 'OPPONENT';
    }
    if (!side) return;

    const scoreConfig = await this.prisma.pKScoreConfig.findFirst({ where: { active: true }, orderBy: { id: 'desc' } });
    const points = pkPointsForCoins(coinAmount, scoreConfig?.coinsPerPoint ?? 1);
    if (points <= 0n) return;

    // Guarded on ACTIVE so a gift racing the settle can't change a final score.
    await this.prisma.pKBattle.updateMany({
      where: { id: battle.id, status: 'ACTIVE' },
      data: side === 'CHALLENGER' ? { scoreChallenger: { increment: points } } : { scoreOpponent: { increment: points } },
    });
  }

  // The "Honor" leaderboard (reference app's top-recipients ranking) —
  // real gift totals from GiftTransaction, grouped by recipient over a
  // window, not a fabricated score. `period` maps to a lookback window
  // rather than a calendar-aligned bucket (no "since midnight in the
  // recipient's timezone" concept anywhere else in this codebase either),
  // same honest-approximation call as ReconciliationService's windows.
  // "Bag" — what a recipient has actually been given, aggregated by gift
  // type rather than a flat transaction log (a flat log could run into
  // the thousands for an active creator; "you have 12x Rose, 3x Crown"
  // is what an inventory view actually needs). Same groupBy + join
  // pattern as ranking() above.
  // The backpack: what this person RECEIVED, day by day (Nigeria time), newest day
  // first — each day lists every gift with how many, what they were worth, and who
  // sent them. This is where received gifts are shown (they no longer create
  // notifications or appear in the header banner).
  async backpack(userId: string, days = 7, now = new Date(), offsetMinutes = DEFAULT_DAY_OFFSET_MINUTES) {
    const span = Math.min(Math.max(Math.floor(days) || 7, 1), 60);
    const today = dayPeriod(now, offsetMinutes);
    const since = new Date(today.start.getTime() - (span - 1) * DAY_MS);
    const rows = await this.prisma.giftTransaction.findMany({
      where: { recipientId: userId, createdAt: { gte: since } },
      orderBy: { createdAt: 'desc' },
      take: 5000,
      select: { giftId: true, senderId: true, coinAmount: true, createdAt: true },
    });
    const giftIds = [...new Set(rows.map((r) => r.giftId))];
    const senderIds = [...new Set(rows.map((r) => r.senderId))];
    const [gifts, senders] = await Promise.all([
      giftIds.length ? this.prisma.gift.findMany({ where: { id: { in: giftIds } }, select: { id: true, code: true, name: true, icon: true } }) : [],
      senderIds.length ? this.prisma.user.findMany({ where: { id: { in: senderIds } }, select: { id: true, displayName: true } }) : [],
    ]);
    const giftById = new Map(gifts.map((g) => [g.id, g]));
    const nameById = new Map(senders.map((s) => [s.id, s.displayName]));
    return groupBackpack(rows, giftById, nameById, today.start, offsetMinutes, span);
  }

  async received(userId: string) {
    const grouped = await this.prisma.giftTransaction.groupBy({
      by: ['giftId'],
      where: { recipientId: userId },
      _sum: { coinAmount: true },
      _count: { _all: true },
      orderBy: { _sum: { coinAmount: 'desc' } },
    });
    if (grouped.length === 0) return [];

    const giftRows = await this.prisma.gift.findMany({
      where: { id: { in: grouped.map((g) => g.giftId) } },
      select: { id: true, name: true, code: true },
    });
    const byId = new Map(giftRows.map((g) => [g.id, g]));

    return grouped
      .map((g) => {
        const gift = byId.get(g.giftId);
        if (!gift) return null; // gift removed from the catalog since it was sent
        return {
          giftId: gift.id,
          giftName: gift.name,
          giftCode: gift.code,
          count: g._count._all,
          totalCoinValue: g._sum.coinAmount ?? 0,
        };
      })
      .filter((row): row is NonNullable<typeof row> => row !== null);
  }

  async ranking(period: 'today' | 'week', limit = 20) {
    const since = new Date(Date.now() - (period === 'today' ? 24 : 24 * 7) * 60 * 60 * 1000);

    const grouped = await this.prisma.giftTransaction.groupBy({
      by: ['recipientId'],
      where: { createdAt: { gte: since } },
      _sum: { coinAmount: true },
      orderBy: { _sum: { coinAmount: 'desc' } },
      take: limit,
    });
    if (grouped.length === 0) return [];

    const recipients = await this.prisma.user.findMany({
      where: { id: { in: grouped.map((g) => g.recipientId) } },
      select: { id: true, displayName: true, countryCode: true },
    });
    const byId = new Map(recipients.map((r) => [r.id, r]));

    return grouped
      .map((g) => {
        const user = byId.get(g.recipientId);
        if (!user) return null; // recipient deleted/deactivated since the gift was sent
        return {
          userId: user.id,
          displayName: user.displayName,
          countryCode: user.countryCode,
          honorScore: g._sum.coinAmount ?? 0,
        };
      })
      .filter((row): row is NonNullable<typeof row> => row !== null);
  }
}
