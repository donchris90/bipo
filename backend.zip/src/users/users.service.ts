import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { SUPPORTED_LANGUAGE_CODES } from '../common/languages';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { WalletService } from '../economy/wallet.service';
import { HostLevelsService } from '../host-levels/host-levels.service';
import { RrydaLevelsService } from '../rryda-levels/rryda-levels.service';
import { TeamsService } from '../teams/teams.service';
import { SeasonsService } from '../seasons/seasons.service';
import { UserStatus, RoleName, WalletType, LedgerEntryType } from '@prisma/client';
import { ReferralConfigService } from '../referral-config/referral-config.service';
import { CHECK_IN_REWARD_SCHEDULE, computeCheckInReward, resolveCheckIn, toUtcDateKey } from './check-in-rules';

const MAX_BIO_LENGTH = 220;

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly wallet: WalletService,
    private readonly hostLevels: HostLevelsService,
    private readonly rrydaLevels: RrydaLevelsService,
    private readonly teams: TeamsService,
    private readonly seasons: SeasonsService,
    private readonly referralConfig: ReferralConfigService,
  ) {}

  async findMe(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { roles: true },
    });
    if (!user) throw new NotFoundException();
    const { passwordHash, ...safe } = user;
    return safe;
  }

  // Real referral list — who signed up using this user's code. Only the
  // fields actually needed to show "you referred these people" (not a
  // full user dump) — deliberately not the same shape as findMe().
  async findMyProfilePhotos(userId: string) {
    return this.prisma.profilePhoto.findMany({
      where: { userId },
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }],
      select: { id: true, url: true, sortOrder: true, createdAt: true },
    });
  }

  async addProfilePhoto(userId: string, url: string) {
    const trimmed = String(url ?? '').trim();
    if (!/^https?:\/\//.test(trimmed)) throw new BadRequestException('Photo URL must be a valid http(s) URL');
    const count = await this.prisma.profilePhoto.count({ where: { userId } });
    if (count >= 8) throw new BadRequestException('You can add up to 8 profile photos');
    return this.prisma.profilePhoto.create({
      data: { userId, url: trimmed, sortOrder: count },
      select: { id: true, url: true, sortOrder: true, createdAt: true },
    });
  }

  async setPrimaryProfilePhoto(userId: string, photoId: string) {
    const photo = await this.prisma.profilePhoto.findFirst({ where: { id: photoId, userId } });
    if (!photo) throw new NotFoundException('Profile photo not found');
    await this.prisma.user.update({ where: { id: userId }, data: { avatarUrl: photo.url } });
    return photo;
  }

  async deleteProfilePhoto(userId: string, photoId: string) {
    const photo = await this.prisma.profilePhoto.findFirst({ where: { id: photoId, userId } });
    if (!photo) throw new NotFoundException('Profile photo not found');
    await this.prisma.profilePhoto.delete({ where: { id: photoId } });
    const remaining = await this.prisma.profilePhoto.findMany({
      where: { userId }, orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }], take: 8,
    });
    if (remaining.length && photo.url === (await this.prisma.user.findUnique({ where: { id: userId }, select: { avatarUrl: true } }))?.avatarUrl) {
      await this.prisma.user.update({ where: { id: userId }, data: { avatarUrl: remaining[0].url } });
    } else if (!remaining.length && photo.url === (await this.prisma.user.findUnique({ where: { id: userId }, select: { avatarUrl: true } }))?.avatarUrl) {
      await this.prisma.user.update({ where: { id: userId }, data: { avatarUrl: null } });
    }
    return { ok: true };
  }

  async findMyReferrals(userId: string) {
    const referrals = await this.prisma.user.findMany({
      where: { referredById: userId },
      select: { id: true, displayName: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });
    // Shape matches the mobile ReferralResponse: the reward amount comes from
    // the same constant AuthService credits (to the BONUS wallet).
    return { referrals, referralBonusCoins: await this.referralConfig.getRewardCoins() };
  }


  async updateNearbyPreferences(userId: string, enabled: boolean, latitude?: number, longitude?: number) {
    if (typeof enabled !== 'boolean') throw new BadRequestException('enabled must be a boolean');
    if (!enabled) {
      return this.prisma.user.update({ where: { id: userId }, data: { nearbyEnabled: false, nearbyLat: null, nearbyLon: null, nearbyUpdatedAt: null }, select: { nearbyEnabled: true } });
    }
    if (!Number.isFinite(latitude) || latitude! < -90 || latitude! > 90 || !Number.isFinite(longitude) || longitude! < -180 || longitude! > 180) {
      throw new BadRequestException('A valid latitude and longitude are required');
    }
    // Store only a coarse location (~1km latitude buckets), never the exact GPS point.
    const lat = Math.round(latitude! * 100) / 100;
    const lon = Math.round(longitude! * 100) / 100;
    return this.prisma.user.update({ where: { id: userId }, data: { nearbyEnabled: true, nearbyLat: lat, nearbyLon: lon, nearbyUpdatedAt: new Date() }, select: { nearbyEnabled: true, nearbyUpdatedAt: true } });
  }

  async getCheckInStatus(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { lastCheckInAt: true, checkInStreak: true },
    });
    if (!user) throw new NotFoundException();
    // resolveCheckIn reads a stale stored streak (a missed day) as 0, so the
    // status never promises a reward the next check-in wouldn't actually pay.
    const state = resolveCheckIn(user.lastCheckInAt, user.checkInStreak, new Date());
    return {
      streak: state.streak,
      alreadyCheckedInToday: state.checkedInToday,
      nextRewardCoins: Number(computeCheckInReward(state.nextStreak)),
      // Coins for streak days 1..7 (day 7 onwards pays the cap).
      rewardSchedule: CHECK_IN_REWARD_SCHEDULE,
    };
  }

  async checkIn(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { lastCheckInAt: true, checkInStreak: true },
    });
    if (!user) throw new NotFoundException();

    const now = new Date();
    const state = resolveCheckIn(user.lastCheckInAt, user.checkInStreak, now);
    if (state.checkedInToday) throw new BadRequestException('Already checked in today');

    const newStreak = state.nextStreak;
    const reward = computeCheckInReward(newStreak);

    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: { lastCheckInAt: now, checkInStreak: newStreak },
      });
      await this.wallet.credit({
        userId,
        walletType: WalletType.BONUS,
        amount: reward,
        ledgerType: LedgerEntryType.BONUS,
        reference: 'daily-check-in',
        idempotencyKey: `check-in-${userId}-${toUtcDateKey(now)}`,
      }, tx);
    });

    void this.rrydaLevels.addXp(userId, 10); // Rryda Identity: showing up counts, every day
    void this.teams.contributeXp(userId, 10); // Rryda Teams: showing up helps your team too
    void this.seasons.contributePoints(userId, 10); // Rryda Seasons: showing up counts toward the current season too
    return { streak: newStreak, rewardCoins: Number(reward) };
  }

  // Self-service profile edits: displayName, avatarUrl and bio are the fields
  // a user should be able to change themselves (email/phone/countryCode are
  // identity fields, kycVerified/status/roles are admin-controlled).
  // Each field is optional and independent — a user changing just their bio
  // shouldn't have to resend an unchanged displayName. avatarUrl is trusted
  // as already-uploaded rather than a file this endpoint receives itself;
  // this only ever stores the resulting URL string. A blank bio clears it.
  async updateMe(userId: string, updates: { displayName?: string; avatarUrl?: string; coverUrl?: string; bio?: string; oneOnOneEnabled?: boolean; languageCode?: string }) {
    const data: { displayName?: string; avatarUrl?: string | null; coverUrl?: string | null; bio?: string | null; oneOnOneEnabled?: boolean; languageCode?: string } = {};

    if (updates.displayName !== undefined) {
      const trimmed = updates.displayName.trim();
      if (!trimmed || trimmed.length < 2 || trimmed.length > 40) {
        throw new BadRequestException('Display name must be between 2 and 40 characters');
      }
      data.displayName = trimmed;
    }

    if (updates.avatarUrl !== undefined) {
      const trimmed = updates.avatarUrl.trim();
      if (trimmed && !/^https?:\/\//.test(trimmed)) {
        throw new BadRequestException('avatarUrl must be a valid http(s) URL');
      }
      data.avatarUrl = trimmed || null;
    }

    if (updates.coverUrl !== undefined) {
      const trimmed = updates.coverUrl.trim();
      if (trimmed && !/^https?:\/\//.test(trimmed)) {
        throw new BadRequestException('coverUrl must be a valid http(s) URL');
      }
      data.coverUrl = trimmed || null;
    }

    if (updates.bio !== undefined) {
      if (typeof updates.bio !== 'string') throw new BadRequestException('bio must be text');
      const trimmed = updates.bio.trim();
      if (trimmed.length > MAX_BIO_LENGTH) {
        throw new BadRequestException(`Bio must be ${MAX_BIO_LENGTH} characters or fewer`);
      }
      data.bio = trimmed || null;
    }

    if (updates.languageCode !== undefined) {
      const languageCode = updates.languageCode.trim().toLowerCase().split(/[-_]/)[0];
      if (!SUPPORTED_LANGUAGE_CODES.has(languageCode)) {
        throw new BadRequestException('Unsupported language');
      }
      data.languageCode = languageCode;
    }

    if (updates.oneOnOneEnabled !== undefined) {
      if (typeof updates.oneOnOneEnabled !== 'boolean') throw new BadRequestException('oneOnOneEnabled must be true or false');
      const creator = await this.prisma.userRole.findFirst({ where: { userId, role: RoleName.CREATOR } });
      if (!creator) throw new BadRequestException('Only hosts can change 1-on-1 availability');
      // Turning this ON before the host has unlocked private 1-on-1 live used
      // to save silently — the switch would sit "on" in the app with no
      // indication that nobody could actually reach them, since the level
      // was only ever checked later, at call time. Enforce it here too, so
      // this endpoint can't be used to bypass the level requirement (the
      // mobile UI now also gates the switch itself — see EditProfileScreen).
      // Turning it OFF is always allowed, at any level.
      if (updates.oneOnOneEnabled) {
        await this.hostLevels.assertUnlock(userId, 'PRIVATE_LIVE', 'private 1-on-1 live');
      }
      data.oneOnOneEnabled = updates.oneOnOneEnabled;
    }

    if (Object.keys(data).length === 0) {
      throw new BadRequestException('Nothing to update');
    }

    const user = await this.prisma.user.update({ where: { id: userId }, data });
    const { passwordHash, ...safe } = user;
    return safe;
  }

  async setStatus(
    targetUserId: string,
    status: UserStatus,
    actorId: string,
    actorRoles: RoleName[],
  ) {
    const user = await this.prisma.user.update({
      where: { id: targetUserId },
      data: { status },
    });

    // Every sensitive admin action is audited, per spec §56/§94 non-negotiables.
    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: `user.status.${status.toLowerCase()}`,
      targetType: 'user',
      targetId: targetUserId,
    });

    const { passwordHash, ...safe } = user;
    return safe;
  }

  // No verification provider integrated — this just records the outcome of
  // a KYC check done elsewhere (manual review, a third-party service not
  // yet wired in). Never treat setting this to true as itself a
  // verification step.
  async setKycVerified(targetUserId: string, verified: boolean, actorId: string, actorRoles: RoleName[]) {
    const user = await this.prisma.user.update({
      where: { id: targetUserId },
      data: { kycVerified: verified },
    });

    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: `user.kyc.${verified ? 'verify' : 'unverify'}`,
      targetType: 'user',
      targetId: targetUserId,
    });

    const { passwordHash, ...safe } = user;
    return safe;
  }
}
